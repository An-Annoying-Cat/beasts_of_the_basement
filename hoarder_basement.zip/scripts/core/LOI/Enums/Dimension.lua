---@enum Dimension
TSIL.Enums.Dimension = {
    CURRENT = -1,
    MAIN = 0,
    SECONDARY = 1,
    DEATH_CERTIFICATE = 2
}