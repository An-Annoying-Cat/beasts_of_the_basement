---@enum HealthType
TSIL.Enums.HealthType = {
    RED = 1,
    SOUL = 2,
    ETERNAL = 3,
    BLACK = 4,
    GOLDEN = 5,
    BONE = 6,
    ROTTEN = 7,
    BROKEN = 8,
    MAX_HEARTS = 9,
}
