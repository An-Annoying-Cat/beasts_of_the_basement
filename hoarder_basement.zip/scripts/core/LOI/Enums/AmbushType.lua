---@enum AmbushType
TSIL.Enums.AmbushType = {
    CHALLENGE_ROOM = 0,
    BOSS_RUSH = 1
}