---@enum CallbackReturnMode
TSIL.Enums.CallbackReturnMode = {
	NONE = 0,
	SKIP_NEXT = 1,
	LAST_WINS = 2,
	NEXT_ARGUMENT = 3
}