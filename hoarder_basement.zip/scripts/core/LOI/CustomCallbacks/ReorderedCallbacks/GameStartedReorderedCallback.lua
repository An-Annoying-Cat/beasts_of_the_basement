--##use CustomCallbacks/ReorderedCallbacks/GameReorderedLogic.lua
--##POST_GAME_STARTED_REORDERED
TSIL.__RegisterCustomCallback(TSIL.Enums.CustomCallback.POST_GAME_STARTED_REORDERED)