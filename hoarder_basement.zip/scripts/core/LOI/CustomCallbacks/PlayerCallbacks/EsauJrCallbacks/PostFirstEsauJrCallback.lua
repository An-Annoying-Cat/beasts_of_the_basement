--##POST_FIRST_ESAU_JR
--##use CustomCallbacks/PlayerCallbacks/EsauJrCallbacks/EsauJrCallbackLogic.lua
TSIL.__RegisterCustomCallback(TSIL.Enums.CustomCallback.POST_FIRST_ESAU_JR)