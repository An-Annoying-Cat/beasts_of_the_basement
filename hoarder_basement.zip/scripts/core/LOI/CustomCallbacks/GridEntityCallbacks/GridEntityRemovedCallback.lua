--##POST_GRID_ENTITY_REMOVED
--##use CustomCallbacks/GridEntityCallbacks/GridEntityUpdateLogic.lua
TSIL.__RegisterCustomCallback(
    TSIL.Enums.CustomCallback.POST_GRID_ENTITY_REMOVED,
    TSIL.Enums.CallbackReturnMode.NONE,
    TSIL.Enums.CallbackOptionalArgType.GENERIC,
    TSIL.Enums.CallbackOptionalArgType.GENERIC
)